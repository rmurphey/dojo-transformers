({
	loadingState: "로드 중...",
	errorState: "죄송합니다. 오류가 발생했습니다."
})

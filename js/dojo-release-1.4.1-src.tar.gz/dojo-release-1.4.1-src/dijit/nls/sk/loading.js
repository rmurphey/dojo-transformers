({
	loadingState: "Zavádzanie...",
	errorState: "Nastala chyba"
})


({
	loadingState: "טעינה...‏",
	errorState: "אירעה שגיאה"
})

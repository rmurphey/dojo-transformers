({
	loadingState: "Indlæser...",
	errorState: "Der er opstået en fejl"
})

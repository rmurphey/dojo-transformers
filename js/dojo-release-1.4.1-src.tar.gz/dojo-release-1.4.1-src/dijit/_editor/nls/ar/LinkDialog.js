({
	createLinkTitle: "خصائص الوصلة",
	insertImageTitle: "خصائص الصورة",
	url: "عنوان URL:",
	text: "الوصف:",
	set: "تحديد"
})
